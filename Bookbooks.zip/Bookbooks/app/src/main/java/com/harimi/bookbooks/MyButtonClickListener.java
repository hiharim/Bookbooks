package com.harimi.bookbooks;

public interface MyButtonClickListener {

    void onClick(int pos);

}
