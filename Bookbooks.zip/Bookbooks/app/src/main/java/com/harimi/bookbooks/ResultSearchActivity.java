package com.harimi.bookbooks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResultSearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_search);
    }
}